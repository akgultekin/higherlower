1. Open dit map in Visual Studio Code
2. Selecteer "welcomepage.html" in de lijst
3. Druk op "Go live" rechtsonder (als je "Live Server" de extensie hebt)