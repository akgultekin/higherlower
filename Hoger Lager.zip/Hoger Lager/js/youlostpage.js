let playAgainButton = document.querySelector(".playAgainButton");

playAgainButton.addEventListener("click", playAgainButtonAction);


function playAgainButtonAction() {

    window.location.href = "index.html"

}